from django.apps import AppConfig


class ApplyleaveConfig(AppConfig):
    name = 'applyleave'
